import 'package:flutter_riverpod/flutter_riverpod.dart';

final countryCodeProvider = StateProvider<Map<String,String>>((ref) {
  return {};

});
