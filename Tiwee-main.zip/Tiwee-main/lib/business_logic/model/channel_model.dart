
class ChannelModel {
  ChannelModel(
      {required this.name,
      required this.iconAddress,
      required this.channelCount});

  String name;
  String iconAddress;
  int channelCount;
}

