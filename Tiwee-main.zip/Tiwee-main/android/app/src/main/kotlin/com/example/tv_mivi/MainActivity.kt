package com.example.Tiwee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
