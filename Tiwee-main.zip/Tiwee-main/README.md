# Tiwee

An IPTV player developed for android/ios devices with flutter

you can watch cahnnel's from all over  the world
you can access channel by selecting your desired country or by category type

UI inspired from : <a href="https://dribbble.com/shots/14754204-IPTVify-App-Ui-Design">Mohammad Reza Farahzad</a>


Want to contribute? I would really appreciate a hand with the development to add more features in this app. Feel free to Fork, edit, then pull!
![Screenshot_2022-02-10-09-40-26-292_com example Tiwee](https://user-images.githubusercontent.com/32876834/153373110-119ef7bd-1bda-4aae-afaf-1f435d6f386b.jpg)
![Screenshot_2022-02-10-09-40-37-499_com example Tiwee](https://user-images.githubusercontent.com/32876834/153373189-b8a72ad2-ed9d-453a-b696-8480122b8f3f.jpg)
![Screenshot_2022-02-10-09-42-13-824_com example Tiwee](https://user-images.githubusercontent.com/32876834/153373193-075057b0-f999-4b5a-bf62-76f863568f6a.jpg)
![Screenshot_2022-02-10-09-42-46-746_com example Tiwee](https://user-images.githubusercontent.com/32876834/153373204-c698775f-346e-4224-9e12-c84a6217eff6.jpg)
![Screenshot_2022-02-10-11-23-14-496_com example Tiwee](https://user-images.githubusercontent.com/32876834/153373209-8b7517c3-15e6-4950-baba-306bace20138.jpg)

